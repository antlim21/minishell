ls -a
