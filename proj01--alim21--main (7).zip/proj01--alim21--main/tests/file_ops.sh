mkdir -p tmp
touch tmp/some_file
ls -1 tmp/

